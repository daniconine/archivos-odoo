## Module <accounting_pdf_reports>

#### 10.11.2023
#### Version 17.0.1.0
##### IMP
- initial release
